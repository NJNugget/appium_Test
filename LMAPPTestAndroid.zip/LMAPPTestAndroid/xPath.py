# -*- coding: UTF-8 -*-

'''
Created on 2015年9月15日

@author: NJNUGGET
'''
# ===================================
# ANDROID控件xPath地址
# ===================================
EIDTTEXT_ANDROID = "//android.widget.EditText"
NOTICE_IMAGE_ANDROID = "//android.widget.ImageView"
REPLY_BUTTON_ANDROID = "//android.widget.LinearLayout[3]/android.widget.ImageView[1]"
SALE_PRODECT_ANDROID = "//android.widget.ListView/android.widget.LinearLayout/android.widget.FrameLayout"
SELECTED_PRODUCT_ANDROID = "//android.widget.ListView[1]/android.widget.FrameLayout[1]"
OPREATION_IMAGE_ADNROID = "//android.support.v4.view.ViewPager[1]/android.widget.FrameLayout[1]/android.widget.ImageView[1]"
SHARE_TOPIC_BUTTON_ANDROID = "//android.widget.LinearLayout[1]/android.widget.FrameLayout[1]/android.widget.RelativeLayout[1]/android.widget.LinearLayout[1]/android.widget.LinearLayout[3]/android.widget.ImageView[1]"

# ===================================
# ANDROID控件ID
# ===================================
COLLECT_PRODUCT_ID_ANDROID = "com.qyer.android.lastminute:id/deal_layout"
IRREGULAR_IMAGE_1_ID_ANDROID = "com.qyer.android.lastminute:id/ivSale1"
NOTICE_DELETE_ID_ANDROID = "com.qyer.android.lastminute:id/iv_notifi_delete"
SEARCH_IMAGE_ID_ANDROID = "com.qyer.android.lastminute:id/ic_left_image"
SELECTED_PRODUCT_LEFT_ID_ANDROID = "com.qyer.android.lastminute:id/llLeftPanle"
SORT_BUTTON_ID_ANDROID = "com.qyer.android.lastminute:id/ivOrderType"




